## flower_classification.Rmd is the R markdown file including the scripts of modeling.

## flowers_result.csv is the file with class predicted.

## flower_classification.html is a file which describe the processing steps when predict the flower's class.
