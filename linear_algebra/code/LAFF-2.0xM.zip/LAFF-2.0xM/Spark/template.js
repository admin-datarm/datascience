var LscriptFns = new Array(LHeader, LPartition, LGuard, LRepartition, LComment, LContinue, LFooter);

function LHeader(n, partitions, fnName){
  var str="";
  return str;
}

function LPartition(){
  var str="";
  return str;
}

function LPart(c, part, blk){
  var str="";
  return str;
}

function LGuard(c, part, section){
  var str="";
  return str;
}

function LRepart(c, part, blk){
  var str="";
  return str;
}

function LComment(){
  var str="";
  return str;
}

function LCont(c, part, blk){
  var str="";
  return str;
}

function LFooter(n, partitions){
  var str="";
  return str;
}
