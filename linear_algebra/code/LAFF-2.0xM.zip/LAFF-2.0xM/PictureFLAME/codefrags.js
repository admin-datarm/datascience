/*      function part(operand, type, dir){
        var elmt = document.getElementById(operand);
        var tbl = elmt.childNodes[1];
        if (type=='2x1' || type=='2x2'){
          tbl.rows[0].className = 'T';
        }
        if (type=='1x2' || type=='2x2'){         
          for (var i = 0; i != tbl.rows.length; ++i){
            tbl.rows[i].cells[0].className += 'L';
          }
        }
      }
     
*/

    /*
          repart(oprdExpr.exec(stmt)[0].replace(/\(\s*/g, '').charAt(0),
               partTypeExpr.exec(stmt)[0], false,
               partDirExpr.exec(stmt)[0].substring(4));
*/

/*          cont_with(oprdExpr.exec(stmt)[0].replace(/\(\s*/g, '').charAt(0),
               partTypeExpr.exec(stmt)[0], false,
               partDirExpr.exec(stmt)[0]);
*/        }